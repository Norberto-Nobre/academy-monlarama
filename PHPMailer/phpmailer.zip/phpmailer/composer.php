{
    "require": {
        "phpmailer/phpmailer": "^6.9"
    }
}
